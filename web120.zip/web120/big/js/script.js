(function($){
$(document).ready(function(){

$("#cssmenu").menumaker({
    title: "Menu",
    breakpoint: 970,
    format: "multitoggle"
});

});
})(jQuery);
