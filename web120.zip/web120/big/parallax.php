
<?php
    include 'includes/header.php';
?>
<div class="parallax-container">
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse feugiat neque pretium massa mattis laoreet. Phasellus vehicula sem et blandit feugiat. Praesent efficitur est elit, sit amet maximus odio fringilla non. Nunc feugiat, turpis nec sagittis blandit, urna lorem molestie libero, ac tincidunt mi sem eu magna. Donec feugiat pharetra dictum. Sed elementum est id imperdiet posuere. Aenean ac vulputate odio. Etiam justo elit, suscipit congue mi eu, dictum laoreet quam. Nunc dapibus nec elit non dignissim. Proin consequat nisi sed arcu molestie hendrerit. Nam finibus diam justo, non rhoncus dui sodales dictum. Suspendisse potenti.</p>
    <div class="parallax">
    
    </div>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse feugiat neque pretium massa mattis laoreet. Phasellus vehicula sem et blandit feugiat. Praesent efficitur est elit, sit amet maximus odio fringilla non. Nunc feugiat, turpis nec sagittis blandit, urna lorem molestie libero, ac tincidunt mi sem eu magna. Donec feugiat pharetra dictum. Sed elementum est id imperdiet posuere. Aenean ac vulputate odio. Etiam justo elit, suscipit congue mi eu, dictum laoreet quam. Nunc dapibus nec elit non dignissim. Proin consequat nisi sed arcu molestie hendrerit. Nam finibus diam justo, non rhoncus dui sodales dictum. Suspendisse potenti.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse feugiat neque pretium massa mattis laoreet. Phasellus vehicula sem et blandit feugiat. Praesent efficitur est elit, sit amet maximus odio fringilla non. Nunc feugiat, turpis nec sagittis blandit, urna lorem molestie libero, ac tincidunt mi sem eu magna. Donec feugiat pharetra dictum. Sed elementum est id imperdiet posuere. Aenean ac vulputate odio. Etiam justo elit, suscipit congue mi eu, dictum laoreet quam. Nunc dapibus nec elit non dignissim. Proin consequat nisi sed arcu molestie hendrerit. Nam finibus diam justo, non rhoncus dui sodales dictum. Suspendisse potenti.</p>
</div>
</section>
<aside><h3>Resources</h3>
<ul>
    <li><a href="https://www.w3schools.com/howto/howto_css_parallax.asp">w3schools</a></li>
    <li><a href="https://materializecss.com/parallax-demo.html">materializecss</a></li>
    </ul>
    <div class="dot">
<iframe src="https://www.youtube.com/embed/d34GsFz-HkY" allowfullscreen></iframe><p>^ this guy helped so much!!</p></div></aside>

<?php
    include 'includes/footer.php';
?>