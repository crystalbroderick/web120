<?php
    include 'includes/header.php';
?>

<div class='embed-container'>
<iframe src="https://www.youtube.com/embed/hKDfhKoKV-A" allowfullscreen></iframe>
</div>

</section>
<aside><h3>First Beach Webcam</h3>
<div class="dot">
    <iframe src="webcam.html" ></iframe></div></aside>
<!--end left column -->

<!--<aside>
    <h3>West Seattle DOT Camera</h3>
    <div class="dot">
    Iframe in a refreshing web page Sara will demonstate :3</div>
</aside>-->
<?php
    include 'includes/footer.php';
?>