<footer>
  <p><small>&copy; 2019 - <?=date('Y')?> by <a href="contact.php">Crystal</a>, All Rights Reserved ~ <a href="http://validator.w3.org/check/referer" target="_blank">Valid HTML</a> ~ <a href="http://jigsaw.w3.org/css-validator/check?uri=referer" target="_blank">Valid CSS</a></small></p>
</footer></div>
<!-- END Footer --> 

    <!-- JavaScript associated with the W3Schools.com Top Navigation Response Exercise --> 
  <!--<script>
    function myFunction() {
        var x = document.getElementById("cssmenu");
        if (x.className === "cssmenu") {
            x.className += " responsive";
        } else {
            x.className = "cssmenu";
        }
    }   
 </script>-->


<!-- END WRAPPER -->

</body>
</html>