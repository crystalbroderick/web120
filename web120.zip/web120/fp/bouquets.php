<?php
    include 'includes/header.php';
?>

<div class="wrapper">
<section class="fullwidth">
<h2 class="pageID"><?=$PageID?></h2>
     <img class="desktop" src="https://picsum.photos/800/600" alt="Lorem Picsum" />
       
     <img class="tablet" src="https://picsum.photos/200/300" alt="Lorem Picsum" />
       
     <img class="phone" src="https://picsum.photos/200/300" alt="Lorem Picsum" />
    
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Volutpat consequat mauris nunc congue nisi. Nec nam aliquam sem et tortor. Vitae et leo duis ut diam quam. Diam vel quam elementum pulvinar etiam non quam lacus. Sit amet venenatis urna cursus. Vitae ultricies leo integer malesuada nunc vel risus. Faucibus ornare suspendisse sed nisi lacus. Dictumst vestibulum rhoncus est pellentesque elit ullamcorper. Nec feugiat in fermentum posuere urna. At in tellus integer feugiat scelerisque. At augue eget arcu dictum varius. Gravida arcu ac tortor dignissim convallis aenean et tortor. Quis auctor elit sed vulputate.
    </p>
<p>Elementum eu facilisis sed odio morbi quis commodo. Libero nunc consequat interdum varius. Amet mattis vulputate enim nulla aliquet porttitor. Sollicitudin nibh sit amet commodo nulla facilisi nullam vehicula ipsum. Velit aliquet sagittis id consectetur purus. Nulla facilisi morbi tempus iaculis urna id volutpat lacus laoreet. Cum sociis natoque penatibus et magnis dis parturient. Ut sem nulla pharetra diam sit amet nisl. Massa sapien faucibus et molestie ac feugiat sed lectus vestibulum. Amet venenatis urna cursus eget.</p>
    
</section>
</div>
<?php
    include 'includes/footer.php';
?>