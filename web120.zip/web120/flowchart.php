<?php
    include 'includes/header.php';
?>
    <p><iframe src="https://docs.google.com/document/d/e/2PACX-1vSVQCf8gwQ0qutDkKVRaXRpZTCziaLl4Fc6BIJt6HondFc1ClkBHp8Yxt_g4LdaA_KXhQBcnTZztnUb/pub?embedded=true" width="600px"></iframe></p>
</section>
<!-- START LEFT COL -->
<aside>
    <h3>Layout Resources</h3>
    <ul>
        <li><a href="https://colibriwp.com/blog/website-layout-design-ideas/">Colibriwp</a></li>
        <li><a href="https://www.crazyegg.com/blog/best-website-layouts/"> Crazyegg</a></li>
    </ul>

</aside>
 
<!-- START Footer -->
<?php
    include 'includes/footer.php';
?>