 <?php
    include 'includes/header.php';
?>

            <h2>Search Engine Optimation (SEO)</h2>
        <div class='embed-container'><iframe src='https://www.youtube.com/embed/hF515-0Tduk' width='600' height='450' allowfullscreen></iframe></div>
        </section> 
         <!-- END LEFT COL -->

         <!-- START RIGHT COL -->
        <aside>
          <h3>Resources</h3>
        <!-- Provide 3 or more links that teach a web developer how to implement SEO -->
        <ol>
               <li><a href="https://five.agency/seo-guide-for-web-developers-2017/">Five Agency</a></li>
               <li><a href="https://www.woorank.com/en/blog/5-seo-guidelines-for-web-developers">Woorank</a></li>
                    <li><a href="https://studywebdevelopment.com/seo-for-web-developers.html">StudyWebDev</a></li>
        </ol>
        </aside>
         <!-- END RIGHT COL -->
<?php
    include 'includes/footer.php';
?>