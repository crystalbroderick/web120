<?php
    include 'includes/header.php';
?>

<div class="wrapper">
<section class="fullwidth">
<h2 class="pageID"><?=$PageID?></h2>
<div class="row"> 
  <div class="column">
    <img src="../fp/images/image1.jpeg" style="width:100%">
    <img src="../fp/images/image2_800_600.jpeg" style="width:100%">

  </div>
  <div class="column">
      <img src="../fp/images/image4.jpg" style="width:100%">
      <img src="../fp/images/IMG_1739.jpg" style="width:100%">
  </div>  
  <div class="column">
    <img src="../fp/images/IMG_1748(3).jpg" style="width:100%">
    <img src="../fp/images/image3_800_600.jpg" style="width:100%">

  </div>
      <div class="column">
          <img src="../fp/images/image5.jpg" style="width:100%">
      <img src="../fp/images/IMG951993.jpg" style="width:100%">
      

  </div>
</div>
</section></div>
<?php
    include 'includes/footer.php';
?>