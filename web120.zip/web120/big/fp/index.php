<?php
    include 'includes/header.php';
?>
<!-- START LEFT COL -->
<section>
 <h2 class="pageID">Client Questionnaire</h2>
<!-- END LEFT COL -->
<aside><h2>Basic Website Design Cycle</h2></aside>

 
<!-- START Footer -->
<?php
    include 'includes/footer.php';
?>