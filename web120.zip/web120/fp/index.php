<?php
    include 'includes/header.php';
?>
<!-- START LEFT COL -->

<!-- END LEFT COL -->
<div class="wrapper">
<section class="fullwidth">
<h2 class="pageID"><?=$PageID?></h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed neque orci, sollicitudin ut finibus a, facilisis viverra felis. Duis consequat, purus eget pellentesque dignissim, lectus eros sodales orci, sit amet auctor libero sapien ut lectus. Nam a sapien non odio suscipit blandit nec at lorem. Donec ac metus est. Mauris bibendum, tortor vitae accumsan venenatis, <strong>sem</strong> leo varius lectus, sit amet tempus nunc lacus vel ipsum. Nullam efficitur lacinia ipsum, eu sollicitudin metus facilisis vitae. Sed non elit sollicitudin, sollicitudin neque et, vehicula dolor. Cras dapibus, dui a <strong>tempus</strong> porta, risus ligula sodales nisi, at aliquet erat sapien eget elit. In viverra faucibus tortor. Vestibulum sit amet mauris quam. Nam gravida elit ac tincidunt sollicitudin. Vivamus et lobortis arcu. Proin vulputate, ante vitae feugiat posuere, enim lorem condimentum libero, ut tempor nisl sem id tortor. Phasellus commodo odio eget auctor consequat.</p>
    <p>Lorem ipsum dolor sit amet, ius nostrud expetenda abhorreant ex, id cum singulis sadipscing efficiantur. Pri expetenda reprehendunt ne, discere perpetua philosophia quo et! Sonet inciderint ad pro. Recteque laboramus cu duo, ei lorem mollis pertinax vel, sonet congue oportere his ad.</p>

<p>Ne mel esse cibo lorem, vel mutat referrentur id! Eos cu facer utamur commodo, in democritum intellegam mel, no his mucius gloriatur scribentur. Cum ei unum aliquid apeirian. Has id malis error feugiat.</p>

    <p>Vix reprimique reformidans concludaturque cu, inermis epicurei mel eu. In eum alii summo regione, no pri <i>senserit</i> scriptorem. Ad vix purto semper, ei rebum illum consul est, an delicata periculis per. Suscipit accusamus gubergren ad pri, epicurei fabellas no sit, ut impetus saperet explicari duo?</p>
    
</section>
</div>
<div class="flexcontainer">
    <div class="container">
        <div class="flexbox">
    <img src="images/puppyhelp.jpg" class="clicky" alt="dog in plants">
    <div class="middle">
        <div class="text"><a href="../fp/safeplants.php">Safe for Animals</a></div>
    </div>
        </div>
    </div>
    <div class="container">
        <div class="flexbox">
    <img src="images/gardeningtips.jpg" class="clicky" alt="image2">
    <div class="middle">
        <div class="text"><a href="../fp/tips.php">Gardening Tips</a></div>
    </div>
        </div>
    </div>
    <div class="container">
        <div class="flexbox">
    <img src="images/boquet.jpg" class="clicky" alt="image3">
    <div class="middle">
        <div class="text"><a href="#">Bouquets</a></div>
    </div>
        </div>
    </div>
</div>
<!-- START Footer -->
<?php
    include 'includes/footer.php';
?>