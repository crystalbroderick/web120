<?php
    include 'includes/header.php';
?>

<div class="wrapper">
<section class="fullwidth">
<h2 class="pageID"><?=$PageID?></h2>

    <?php include 'includes/simple.php';?>
<p class="clear-recaptcha"></p>
    
</section>
</div>
<?php
    include 'includes/footer.php';
?>