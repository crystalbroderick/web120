<?php
    include 'includes/header.php';
?>
</section>
<!-- MAKE SURE YOU GET YOUR (3) IMAGES SAVED INTO YOUR IMAGES FOLDER -->
<!-- START LEFT COL -->
    <img src="images/desktop.jpg" class="desktop" alt="Me and my bf" />
    <img src="images/tablet.jpg" class="tablet" alt="Feeding a goat">
     <img src="images/phone.jpg" class="phone" alt="my cat about to knock off my pen" />
    <h2>About Me</h2>
    <p>I've been attending SCC full time for over a year now, and on track for AAS programming!</p>

    <p>I go to school days and work graveyard, and play video games when I have any spare time. I'm excited to learn back end dev and some designing!</p>



<!-- END LEFT COL -->

<!-- START RIGHT COL -->
<!-- END RIGHT COL -->
 
<!-- START Footer -->
<?php
    include 'includes/footer.php';
?>