<?php
    include 'includes/header.php';
?>

<!-- MAKE SURE YOU GET YOUR (3) IMAGES SAVED INTO YOUR IMAGES FOLDER -->
<!-- START LEFT COL -->
<!-- START LEFT COL -->

<?php include 'includes/multiple.php';?>
<p class="clear-recaptcha"></p>

</section>
<!-- END LEFT COL -->

<!-- START RIGHT COL -->
<aside>
    <h3>Basic Website Design Cycle</h3>
    <p>
    <ul>
        <li><a href="https://www.idesignstudios.com/web-design/phases-web-design-development-process/">idesignsstudios</a></li>
        <li><a href="https://www.smashingmagazine.com/2011/06/following-a-web-design-process/">idesignsstudios</a></li>
        <li><a href="https://webflow.com/blog/the-web-design-process-in-7-simple-steps">webflow</a></li>
    </ul>
</aside>
<!-- END RIGHT COL -->
 
<!-- START Footer -->
<?php
    include 'includes/footer.php';
?>