<?php
    include 'includes/header.php';
?>
<?php
    include 'includes/multiple.php';
    ?>
    <p class="clear-recaptcha"></p>
</section>
<!-- START LEFT COL -->
 
<!-- START Footer -->
<?php
    include 'includes/footer.php';
?>