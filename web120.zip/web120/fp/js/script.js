(function($){
$(document).ready(function(){

$("#cssmenu").menumaker({
    title: "Menu",
    breakpoint: 620,
    format: "multitoggle"
});

});
})(jQuery);


